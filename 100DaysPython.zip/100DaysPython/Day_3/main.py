# Day_3 -> Conditional Statement, Logical Operator, Code Blocks and Scope

# Conditional Statement
#       if condition:
#           do this
#       else:
#           do this


# Nested if else