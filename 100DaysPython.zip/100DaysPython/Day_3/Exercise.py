# Write a program to find number is even or not

#Which number do you want to check?
number = int(input())
# Don't change code above
#############################
# Write your code below

if number % 2 == 0:
    print("Even")
else:
    print("odd")