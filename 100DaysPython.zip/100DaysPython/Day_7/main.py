# Today we gonna learn topics =>
    # For & While loops
    # If/else
    # Lists
    # Strings 
    # Range
    # Modules

