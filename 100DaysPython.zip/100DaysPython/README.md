# 100DaysPython

# command to generate and puch code on github when new repo is created
echo "# 100DaysPython" >> README.md
git init
git add README.md
git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/prashant-i3/100DaysPython.git
git push -u origin main

# Commands to push code on github
git remote add origin https://github.com/prashant-i3/100DaysPython.git
git branch -M main
git push -u origin main