# Functions:    
# First define the function
# Then Call the function



def my_function():
    print("Hello function")

my_function()


# Indentation : provides readers with a sense of continuity.
# in Python:- Indentation in Python refers to the whitespaces (spaces or tabs) at the start of the line to indicate a block of code. The leading whitespaces (space and tabs) at the start of a line are used to determine the indentation level of the line.

# For Loop:
# for item in list_of_items:
#     # Do something to each item

# for number in range(a, b):
#     print(number)

# While 
# while something is true:
#     # Do something repeatedly

