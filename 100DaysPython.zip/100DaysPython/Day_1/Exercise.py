# There are two variables, a and b from input
a = input()
b = input()


# Don't change the code above
#############################
# Write your code here


# Write your code above this line
print("a: " + a)
print("b: " + b)



# Exercise 2
# Q Which of the following code segment shows error
