
print("Hello World!") 

# String manipulation and code intelligence
print("Hello World!\nHello World!")
#  "\n" -> line break

print("Prasahnt" + " " + "Pandey")
# "+"" -> merges two strings 

print("Exercise Solution:")

print("Day 1 - String Manipulation")
print('String Concatenation is done with the "+" sign.\ne.g. print("Hello" + "World!")')
print("New line can be created with a backslash and n.")

# Input function

# "input" -> A prompt for the user
input("What is your name?")

# input() -> will get user input in console
# print() -> will print the word "Hello" and the user input
print("Hello " + input("What is your name?"))

# len() -> gives length of input
print(len(input()))