name = input("What is your name?")
print(name)

name("Prashant")
print(name)

name("Pandey")
print(name)


print("Exercise Solution:")

# There are two variables, a and b from input
a = input()
b = input()

# Don't change the code above
#############################
# Write your code below here
c = a
a = b
b = c

# Write your code above this line
print("a: " + a)
print("b: " + b)

