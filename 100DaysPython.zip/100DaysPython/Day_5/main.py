# Loops :- The loop aloows us to execute same line of code multiple times.
fruits = ["Apple", "Peach", "Pear"]
for fruit in fruits:
    print(fruit)
    print(fruit + " Pie")
print(fruits)