Types of data types:
    * String
     "hello"[0]

    * Integer : large number using underscore instead of comma, python ignores that underscore but it wouls easy for us to read it
     print(123_456_789)

    * Float
     30145

    * Boolean
     True && False