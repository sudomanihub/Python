# when yu divide you always got float

# # - Rules for mathematical opration 
    # PEDMAS
    # P -> Parenthesis <- ()
    # E -> Exponent    <- **
    # D -> Divide      <- /
    # M -> Multiply    <- *
    # A -> Add         <- +
    # S -> Subtract    <- -

# Actually there is two things:-
# Multiplication and division both are equally priortized
# same with add and subtract
print(3 * 3 / 3 + 3 + 3 - 3)
