# num_char = len(input("What is your name?"))

# new_num_char = str(num_char)

# # # This line gives error
# # print("Your name has" + num_char + "characters.")

# # So instead using above line of code -- we use "type()" or typecast it.
# print("Your name has " + new_num_char + " characters.")

a = 123
print(type(a))

a = "123"
print(type(a))

a = 123.23
print(type(a))

print(70 + float("100.5"))


# In summary, you can use type  function to investigate the data type you're working with