# Round into 2 decimal places
print(round(2.666666666666, 2))

# Floor division : '//' instead '/' 
# '/' -> gives float
# '//' -> it gives whole number with converting into int


score = 0

print("Your score is " + str(score)) # here we have to convert our data type
# F string
print(f"Your score is {score}") 
 




