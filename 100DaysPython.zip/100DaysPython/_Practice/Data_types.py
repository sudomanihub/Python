# Python keyword
import keyword
print(keyword.kwlist)

# type()
print(type(23))

# Arithmetic Operator : + - * / % // **
divide = 4/2
print(divide)

remainder = 4%2
print(remainder)

print("This", divide, remainder)

exponent = 3**4
print(exponent)

# Floor division operator
floor_division = 4//3
print(floor_division)
print(type(floor_division))

a = 10
b = 2
print(f"a%b = {a%b}")
print(f"a-(b * (a // b)) = {a-(b * (a // b))}")

# print(-10 - (3 * (-10 // 3)))

