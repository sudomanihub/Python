bookshelf = []
bookshelf.append("The Effective Engineer")
bookshelf.append("The 4 Hour Work Week")
print(bookshelf[0]) # The Effective Engineer
print(bookshelf[1]) # The 4 Hour Work Week

my_integers = [5, 7, 1, 3, 4]
my_integers.append(10)
print(my_integers[0]) # 5
print(my_integers[1]) # 7
print(my_integers[4]) # 4
print(my_integers[5]) # 10