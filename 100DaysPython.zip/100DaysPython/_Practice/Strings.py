# s = "Hello"
# print("s[0] = " + s[0])
# print("s[4] = " + s[4])
# print("s[-0] = " + s[-0])
# print("s[-1] = " + s[-1])
# print("s[-2] = " + s[-2])
# print(s[3:4])

my_Strings = [
"Toshiaki",
"Juliana",
"Yuji",
"Bruno",
"Kaio"
]
print(my_Strings[4]) # Kaio
print()
print(my_Strings[0:4])